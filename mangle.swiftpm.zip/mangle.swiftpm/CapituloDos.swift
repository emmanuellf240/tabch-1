//
//  Inicio.swift
//  mangle
//
//  Created by ADMIN UNACH on 02/03/24.
//

import SwiftUI
import AVKit
struct CapituloDos: View {
    
    @State private var showMenu=false
    @State private var showTres=false
    @State private var showUno=false
    @State private var iterador=0
    @State private var Chat = ["¡Hola! Mi nombre es Jaime la jaiba. Aquí te presento mi hábitat y el de muchos otros animales...", "Algunos de mis vecinos son los cocodrilos, los monos aulladores e incluso los jaguares y las aves migratorias...", "Además este lugar es muy especial, ya que las plantas que se encuentran aquí crecen en condiciones sorprendentes...", "También hay suelos fangosos pobres en oxígeno, altas temperaturas, mareas extremas y vientos fuertes."]
    
    @State private var reproductor: AVAudioPlayer?
     
    
    
    var body: some View {
        
            ZStack {
                // aqui inicia el menu
                
                
                
                
                
                Text("Capitulo II")
                    .font(Font.custom("Nunito Sans", size: 24))
                    .foregroundColor(.black)
                    .offset(x: 0, y: -560)
                
                Text("Nuestro hogar")
                    .font(Font.custom("Otomanopee One", size: 48))
                    .multilineTextAlignment(.center)
                    .foregroundColor(.black)
                    .frame(width: 437, height: 89, alignment: .center).offset(x: 0, y: -520)
                
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 60, height: 60)
                    .background(
                        Image("FlechaIzquierda")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 60, height: 60)
                            .clipped().offset(x: -350, y: -520)
                    ).onTapGesture {
                        showUno.toggle()
                    }.fullScreenCover(isPresented: $showUno){
                        
                        CapituloUno()
                    }
                
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 60, height: 60)
                    .background(
                        Image("FlechaDerecha")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 60, height: 60)
                            .clipped().offset(x: 350, y: -520)
                        
                    ).onTapGesture {
                        showTres.toggle()
                    }.fullScreenCover(isPresented: $showTres){
                        
                        CapituloTres()
                    }
                
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 60, height: 60)
                    .background(
                        Image("Casa")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 60, height: 60)
                            .clipped().offset(x: -270, y: -520)
                    ).onTapGesture {
                        showMenu.toggle()
                    }.fullScreenCover(isPresented: $showMenu){
                        
                        inicio()
                    }
                
                
                
                
                
                
                Text("\(Chat[iterador])")
                    .font(Font.custom("Nunito Sans", size: 35))
                    .foregroundColor(.black)
                    .frame(width: 551, height: 177, alignment: .leading)
                    .offset(x: 0, y: -340)
                
    
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 842, height: 764)
                    .background(
                        Image("FondoUno")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 842, height: 764)
                            .clipped().offset(x: -4, y: 215)
                    )
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 216, height: 181)
                    .background(
                        Image("Jaime")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 216, height: 181)
                            .clipped().offset(x: 305, y: -130)
                        
                    )
                
                
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 752, height: 288)
                    .background(
                        Image("Chat")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 752, height: 288)
                            .clipped().offset(x: 0, y: -340)
                        
                    )
                
                
                

                Rectangle()
                                  .foregroundColor(.clear)
                                  .frame(width: 40, height: 30)
                                  .background(
                                    Image(systemName: "arrowshape.turn.up.forward.fill")
                                      .resizable()
                                      .aspectRatio(contentMode: .fill)
                                      .frame(width: 40, height: 30)
                                      .clipped().offset(x: 280, y: -230).foregroundColor(.black)
                                    
                                  ).onTapGesture {
                                      
                                      if (iterador<3){
                                          iterador+=1
                                      }else{
                                          
                                      }
                                  }

                Rectangle()
                  .foregroundColor(.clear)
                  .frame(width: 130, height: 130)
                  .background(
                    Image("Aguililla")
                      .resizable()
                      .aspectRatio(contentMode: .fill)
                      .frame(width: 130, height: 130)
                      .clipped().offset(x: 200, y: 9)
                  ).onTapGesture {
                      
                  }
                
                Rectangle()
                  .foregroundColor(.clear)
                  .frame(width: 200, height: 200)
                  .background(
                    Image("cocodrilo")
                      .resizable()
                      .aspectRatio(contentMode: .fill)
                      .frame(width: 210, height: 200)
                      .clipped().offset(x: -120, y: 499)
                  ).onTapGesture {
                      
                  }
                
                Rectangle()
                  .foregroundColor(.clear)
                  .frame(width: 150, height: 146.36563)
                  .background(
                    Image("GarzaAzul")
                      .resizable()
                      .aspectRatio(contentMode: .fill)
                      .frame(width: 150, height: 146.36563110351562)
                      .clipped().offset(x: 340, y: 120)
                  )
                
                Rectangle()
                  .foregroundColor(.clear)
                  .frame(width: 150, height: 150)
                  .background(
                    Image("Pez")
                      .resizable()
                      .aspectRatio(contentMode: .fill)
                      .frame(width: 150, height: 150)
                      .clipped().offset(x: 200, y: 450)
                  )
                
                Rectangle()
                  .foregroundColor(.clear)
                  .frame(width: 200, height: 200)
                  .background(
                    Image("Jaguar")
                      .resizable()
                      .aspectRatio(contentMode: .fill)
                      .frame(width: 200, height: 200)
                      .clipped().offset(x: -352, y: 170)
                  ).onTapGesture {
                      
                      var url = URL(string: Bundle.main.path(forResource: "jaguar", ofType: "wav")!)!
                      
                      reproductor = try! AVAudioPlayer(contentsOf: url )
                      reproductor?.prepareToPlay()
                      reproductor?.play()
                  }
                
                
                
                
                
            }
            .frame(width: 834, height: 1194)
            .background(Color(red: 0.95, green: 0.95, blue: 0.86))
            
        
        
    }
}

#Preview {
    CapituloDos()
}
