//
//  Inicio.swift
//  mangle
//
//  Created by Fernando Cruz Hernández on 03/03/24.
//

import SwiftUI

struct inicio: View {
    
    @State private var showUno=false
    @State private var showDos=false
    @State private var showTres=false
    @State private var showCuatro=false
    @State private var showCinco=false
    
    var body: some View {
       
            ZStack {
                
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 834, height: 1194)
                    .background(
                        Image("ArbolMenu")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 840, height: 1200)
                            .clipped()
                            .opacity(100)
                    ).offset(x: 0, y: 0)
                
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 1040, height: 305)
                    .background(
                        Image("Agua")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 1040, height: 305)
                            .clipped()
                            .opacity(0.4)
                    ).offset(x: 0, y: 436)
                
                Button(action:{
                    
                    showUno.toggle()
                    
                }, label: {
                    Text("   Mi nuevo amigo").font(.title).foregroundColor(.black).bold().frame(width: 347, height: 100, alignment: .leading).background(Color(red: 0.31, green:0.78, blue: 0.74))
                        .cornerRadius(300)
                        .shadow(color:.black.opacity(0.2),radius: 2, x: 0, y: 2)
                        .shadow(color: .black.opacity(0.12), radius: 5, x: 0, y: 1)
                        .shadow(color: .black.opacity(0.14), radius: 2.5, x: 0, y: 4)
                }).offset(x: -220, y: -300)
                    .fullScreenCover(isPresented: $showUno){
                        
                        CapituloUno()
                        
                        
                    }
                
                
                
                
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 80, height: 80)
                    .background(
                        Image("Mangle")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 80, height: 80)
                            .clipped().offset(x: -120, y: -300)
                    )
                
                
                
                
                
                Button(action:{
                    showDos.toggle()
                }, label: {
                    Text("   Nuestro hogar").font(.title).foregroundColor(.black).bold().frame(width: 347, height: 100, alignment: .leading).background(Color(red: 0.31, green:0.78, blue: 0.74))
                        .cornerRadius(300)
                        .shadow(color:.black.opacity(0.2),radius: 2, x: 0, y: 2)
                        .shadow(color: .black.opacity(0.12), radius: 5, x: 0, y: 1)
                        .shadow(color: .black.opacity(0.14), radius: 2.5, x: 0, y: 4)
                }).offset(x: 220, y: -300).fullScreenCover(isPresented: $showDos){
                    CapituloDos()
                    
                    
                }
                
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 80, height: 80)
                    .background(
                        Image("Garza")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 80, height: 80)
                            .clipped().offset(x: 320, y: -300)
                    )
                
                
                
                
                Button(action:{
                    showCuatro.toggle()
                }, label: {
                    Text("   El escudero").font(.title).foregroundColor(.black).bold().frame(width: 347, height: 100, alignment: .leading).background(Color(red: 0.31, green:0.78, blue: 0.74))
                        .cornerRadius(300)
                        .shadow(color:.black.opacity(0.2),radius: 2, x: 0, y: 2)
                        .shadow(color: .black.opacity(0.12), radius: 5, x: 0, y: 1)
                        .shadow(color: .black.opacity(0.14), radius: 2.5, x: 0, y: 4)
                }).offset(x: 220, y: -0).fullScreenCover(isPresented: $showCuatro){
                    CapituloCuatro()
                    
                    
                }
                
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 80, height: 80)
                    .background(
                        Image("Escudo")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 80, height: 80)
                            .clipped().offset(x: 320, y: 0)
                    )
                
                
                
                
                
                
                
                Button(action:{
                    showTres.toggle()
                }, label: {
                    Text("   ¡Respira!").font(.title).foregroundColor(.black).bold().frame(width: 347, height: 100, alignment: .leading).background(Color(red: 0.31, green:0.78, blue: 0.74))
                        .cornerRadius(300)
                        .shadow(color:.black.opacity(0.2),radius: 2, x: 0, y: 2)
                        .shadow(color: .black.opacity(0.12), radius: 5, x: 0, y: 1)
                        .shadow(color: .black.opacity(0.14), radius: 2.5, x: 0, y: 4)
                }).offset(x: -220, y: -0).fullScreenCover(isPresented: $showTres){
                    CapituloTres()
                    
                    
                }
                
                
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 80, height: 80)
                    .background(
                        Image("Nube")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 80, height: 80)
                            .clipped().offset(x: 3-110, y: 0)
                    )
                 
                
                
                Button(action:{
                    showCinco.toggle()
                }, label: {
                    Text("   Un nuevo mundo").font(.title).foregroundColor(.black).bold().frame(width: 347, height: 100, alignment: .leading).background(Color(red: 0.31, green:0.78, blue: 0.74))
                        .cornerRadius(300)
                        .shadow(color:.black.opacity(0.2),radius: 2, x: 0, y: 2)
                        .shadow(color: .black.opacity(0.12), radius: 5, x: 0, y: 1)
                        .shadow(color: .black.opacity(0.14), radius: 2.5, x: 0, y: 4)
                }).offset(x: 0, y: 300).fullScreenCover(isPresented: $showCinco){
                    CapituloCinco()
                    
                    
                }
                
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 80, height: 80)
                    .background(
                        Image("Corazon")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 80, height: 80)
                            .clipped().offset(x: 120, y: 300)
                    )
        }
        
    }
}

#Preview {
    inicio()
}
