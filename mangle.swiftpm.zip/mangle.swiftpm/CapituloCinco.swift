//
//  CapituloCuatro.swift
//  mangle
//
//  Created by Fernando Cruz Hernández on 03/03/24.
//

import SwiftUI

struct CapituloCinco: View {
    @State private var showMenu=false
    @State private var showCuatro=false
    @State private var opacidadFrase: Double = 0.0
    @State private var arbol1: Double = 0.0
    @State private var arbol2: Double = 0.0
    @State private var arbol3: Double = 0.0
    @State private var arbol4: Double = 0.0
    @State private var acumulador = 0
    
    
    func verFrase(){
        acumulador+=1
        if (acumulador == 4){
            opacidadFrase = 100.0
        }
    }
    
    var body: some View {
        ZStack{
            
            // aqui inicia el menu
            Text("Capitulo V")
              .font(Font.custom("Nunito Sans", size: 24))
              .foregroundColor(.black)
              .offset(x: 0, y: -560)
            
            Text("Un nuevo mundo")
              .font(Font.custom("Otomanopee One", size: 48))
              .multilineTextAlignment(.center)
              .foregroundColor(.black)
              .frame(width: 437, height: 89, alignment: .center).offset(x: 0, y: -520)
            
            Text("'Lucha por un lugar mejor'")
                .font(Font.custom("Otomanopee One", size: 60))
              .multilineTextAlignment(.center)
              .foregroundColor(.black)
              .frame(width: 837, height: 89, alignment: .center).offset(x: 0, y: -320).opacity(opacidadFrase)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 60, height: 60)
              .background(
                Image("FlechaIzquierda")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 60, height: 60)
                  .clipped().offset(x: -350, y: -520)
              ).onTapGesture {
                  showCuatro.toggle()
              }.fullScreenCover(isPresented: $showCuatro){
                  
                  CapituloCuatro()
              }
            
            
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 60, height: 60)
              .background(
                Image("Casa")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 60, height: 60)
                  .clipped().offset(x: 350, y: -520)
                
              ).onTapGesture {
                  showMenu.toggle()
              }.fullScreenCover(isPresented: $showMenu){
                  
                  inicio()
              }
  
            Image("Ellipse")
                .frame(width: 250, height: 251.43677)
              .shadow(color: .black.opacity(0.25), radius: 2, x: 0, y: 4).offset(x: 0, y: -90)
            
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 1217, height: 647)
              .background(
                Image("Rio")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 835, height: 647)
                  .clipped()
              ).offset(x: 0, y: 273)
            
            
            //abajoizquierda
            Button(action:{
                arbol3 = 100.0
                verFrase()
            }, label: {
                Text("Vida").font(.title).foregroundColor(.black).bold().frame(width: 100, height: 100, alignment: .center).background(Color(red: 0.45, green: 0.72, blue: 0.52))
                    .cornerRadius(300)
                    .shadow(color:.black.opacity(0.2),radius: 2, x: 0, y: 2)
                    .shadow(color: .black.opacity(0.12), radius: 5, x: 0, y: 1)
                    .shadow(color: .black.opacity(0.14), radius: 2.5, x: 0, y: 4)
            }).offset(x: -200, y: 310)
            
            Button(action:{
                arbol1 = 100.0
                verFrase()
            }, label: {
                Text("Vida").font(.title).foregroundColor(.black).bold().frame(width: 100, height: 100, alignment: .center).background(Color(red: 0.45, green: 0.72, blue: 0.52))
                    .cornerRadius(300)
                    .shadow(color:.black.opacity(0.2),radius: 2, x: 0, y: 2)
                    .shadow(color: .black.opacity(0.12), radius: 5, x: 0, y: 1)
                    .shadow(color: .black.opacity(0.14), radius: 2.5, x: 0, y: 4)
            }).offset(x: 200, y: 170)
            //arribaizquierda
            Button(action:{
                arbol4 = 100.0
                verFrase()
            }, label: {
                Text("Vida").font(.title).foregroundColor(.black).bold().frame(width: 100, height: 100, alignment: .center).background(Color(red: 0.45, green: 0.72, blue: 0.52))
                    .cornerRadius(300)
                    .shadow(color:.black.opacity(0.2),radius: 2, x: 0, y: 2)
                    .shadow(color: .black.opacity(0.12), radius: 5, x: 0, y: 1)
                    .shadow(color: .black.opacity(0.14), radius: 2.5, x: 0, y: 4)
            }).offset(x: -350, y: 0)
            //abajoDerecha
            Button(action:{
                arbol2 = 100.0
                verFrase()
            }, label: {
                Text("Vida").font(.title).foregroundColor(.black).bold().frame(width: 100, height: 100, alignment: .center).background(Color(red: 0.45, green: 0.72, blue: 0.52))
                    .cornerRadius(300)
                    .shadow(color:.black.opacity(0.2),radius: 2, x: 0, y: 2)
                    .shadow(color: .black.opacity(0.12), radius: 5, x: 0, y: 1)
                    .shadow(color: .black.opacity(0.14), radius: 2.5, x: 0, y: 4)
            }).offset(x: 350, y: 500)
            
            Rectangle()
                          .foregroundColor(.clear)
                          .frame(width: 150, height: 171.5311)
                          .background(
                            Image("MangleMediano")
                              .resizable()
                              .aspectRatio(contentMode: .fill)
                              .frame(width: 150, height: 171.53109741210938)
                              .clipped().offset(x: 200, y: 40)
                          ).opacity(arbol1)
            
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 150, height: 171.5311)
              .background(
                Image("MangleGrande")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 150, height: 171.53109741210938)
                  .clipped().offset(x: 350, y: 20)
              ).opacity(arbol1)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 150, height: 171.5311)
              .background(
                Image("MangleGrande")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 150, height: 171.53109741210938)
                  .clipped().offset(x: 350, y: 190)
              ).opacity(arbol1)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 150, height: 171.5311)
              .background(
                Image("PlantaAgua")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 140, height: 141.53109741210938)
                  .clipped().offset(x: 70, y: 190)
              ).opacity(arbol1)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 150, height: 171.5311)
              .background(
                Image("ManglePequeño")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 150, height: 171.53109741210938)
                  .clipped().offset(x: 320, y: 360)
              ).opacity(arbol2)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 150, height: 171.5311)
              .background(
                Image("MangleMediano")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 150, height: 171.53109741210938)
                  .clipped().offset(x: 130, y: 370)
              ).opacity(arbol2)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 150, height: 171.5311)
              .background(
                Image("PlantaAgua")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 130, height: 131.53109741210938)
                  .clipped().offset(x: 220, y: 500)
              ).opacity(arbol2)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 150, height: 171.5311)
              .background(
                Image("ManglePequeño")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 150, height: 171.53109741210938)
                  .clipped().offset(x: -300, y: 500)
              ).opacity(arbol3)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 150, height: 171.5311)
              .background(
                Image("MangleGrande")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 150, height: 171.53109741210938)
                  .clipped().offset(x: -340, y: 300)
              ).opacity(arbol3)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 150, height: 171.5311)
              .background(
                Image("ManglePequeño")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 150, height: 171.53109741210938)
                  .clipped().offset(x: -80, y: 300)
              ).opacity(arbol3)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 150, height: 171.5311)
              .background(
                Image("PlantaAgua")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 120, height: 151.53109741210938)
                  .clipped().offset(x: -170, y: 450)
              ).opacity(arbol3)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 150, height: 171.5311)
              .background(
                Image("MangleGrande")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 150, height: 171.53109741210938)
                  .clipped().offset(x: -200, y: -30)
              ).opacity(arbol4)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 150, height: 171.5311)
              .background(
                Image("MangleMediano")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 150, height: 171.53109741210938)
                  .clipped().offset(x: -310, y: 134)
              ).opacity(arbol4)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 150, height: 171.5311)
              .background(
                Image("PlantaAgua")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 120, height: 151.53109741210938)
                  .clipped().offset(x: -160, y: 140)
              ).opacity(arbol4)
            
            
            
        } .frame(width: 834, height: 1194)
            .background(Color(red: 0.95, green: 0.95, blue: 0.86))
            
    }
}

#Preview {
    CapituloCinco()
}
