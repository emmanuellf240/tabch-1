//
//  CapituloTres.swift
//  mangle
//
//  Created by Fernando Cruz Hernández on 03/03/24.
//

import SwiftUI

struct CapituloTres: View {
    @State private var showMenu=false
    @State private var showCuatro=false
    @State private var showDos=false
    @State private var opacidadChat: Double = 0.0
    @State private var nube1: Double = 100.0
    @State private var nube2: Double = 100.0
    @State private var nube3: Double = 100.0
    @State private var nube4: Double = 100.0
    @State private var nube5: Double = 100.0
    @State private var nube6: Double = 100.0
    @State private var nube7: Double = 100.0
    @State private var acumulador = 0
    @State private var iterador=0
    @State private var Chat = ["Hola mi nombre es super Rito el mangle...", "Uno de mis superpoderes es la capacidad de limpiar el aire hasta 50 veces más que un bosque tropical...", "Después almacenamos lo extraído llamado CO2 en las raíces atrapadolos en el suelo fangoso...", "También regulamos la temperatura de la costa ya que soportamos los rayos de sol."]
    
      

    
    
    func verChat(){
        if (acumulador==7){
          opacidadChat=100.0
          }
    }
    
    
    var body: some View {
        
        ZStack {
            
            
            
            Text("Capitulo III")
              .font(Font.custom("Nunito Sans", size: 24))
              .foregroundColor(.black)
              .offset(x: 0, y: -560)
            
            Text("¡Respira!")
              .font(Font.custom("Otomanopee One", size: 48))
              .multilineTextAlignment(.center)
              .foregroundColor(.black)
              .frame(width: 437, height: 89, alignment: .center).offset(x: 0, y: -520)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 60, height: 60)
              .background(
                Image("FlechaIzquierda")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 60, height: 60)
                  .clipped().offset(x: -350, y: -520)
              ).onTapGesture {
                  showDos.toggle()
              }.fullScreenCover(isPresented: $showDos){
                  
                  CapituloDos()
                  
              }
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 60, height: 60)
              .background(
                Image("FlechaDerecha")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 60, height: 60)
                  .clipped().offset(x: 350, y: -520)
                
              ).onTapGesture {
                  showCuatro.toggle()
              }.fullScreenCover(isPresented: $showCuatro){
                  CapituloCuatro()
              }
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 60, height: 60)
              .background(
                Image("Casa")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 60, height: 60)
                  .clipped().offset(x: -270, y: -520)
              ).onTapGesture {
                  showMenu.toggle()
              }.fullScreenCover(isPresented: $showMenu){
                  
                  inicio()
              }
            
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 834, height: 138)
              .background(Color(red: 0.28, green: 0.7, blue: 0.68)).offset(x: 0, y: 550)
            
            Rectangle()
                          .foregroundColor(.clear)
                          .frame(width: 921, height: 921)
                          .background(
                            Image("ArbolRespira")
                              .resizable()
                              .aspectRatio(contentMode: .fill)
                              .frame(width: 921, height: 921)
                              .clipped()
                          ).offset(x: 0, y: 110)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 100, height: 100)
              .background(
                Image("NubeUno")
                    .resizable().opacity(nube1)
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 100, height: 100)
                  .clipped()
              ).offset(x: -250, y: -290).onTapGesture {
                  nube1 = 0.0
                  acumulador+=1
                  
                  verChat()

              }
            
            
            
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 100, height: 100)
              .background(
                Image("NubeUno")
                  .resizable().opacity(nube2)
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 100, height: 100)
                  .clipped()
              ).offset(x: -40, y: -380).onTapGesture {
                  nube2 = 0.0
                  acumulador+=1
              }
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 100, height: 100)
              .background(
                Image("NubeUno")
                    .resizable().opacity(nube3)
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 100, height: 100)
                  .clipped()
              ).offset(x: 250, y: -300).onTapGesture {
                  nube3 = 0.0
                  acumulador+=1
                  
                  verChat()
              }
            
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 100, height: 100)
              .background(
                Image("NubeUno")
                    .resizable().opacity(nube4)
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 100, height: 100)
                  .clipped()
              ).offset(x: 100, y: -250).onTapGesture {
                  nube4 = 0.0
                  acumulador+=1
                  
                  verChat()
              }
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 100, height: 100)
              .background(
                Image("NubeDos")
                    .resizable().opacity(nube5)
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 100, height: 100)
                  .clipped()
              ).offset(x: 330, y: -150).onTapGesture {
                  nube5 = 0.0
                  acumulador+=1
                  
                  verChat()
              }
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 100, height: 100)
              .background(
                Image("NubeDos")
                    .resizable().opacity(nube6)
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 100, height: 100)
                  .clipped()
              ).offset(x: -80, y: -250).onTapGesture {
                  nube6 = 0.0
                  acumulador+=1
                  
                  verChat()
              }
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 100, height: 100)
              .background(
                Image("NubeDos")
                    .resizable().opacity(nube7)
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 100, height: 100)
                  .clipped()
              ).offset(x: -300, y: -150).onTapGesture {
                  nube7 = 0.0
                  acumulador+=1
                  verChat()
              }
            
            Text("\(Chat[iterador])")
                .font(Font.custom("Nunito Sans", size: 35))
                .foregroundColor(.black)
                .frame(width: 600, height: 177, alignment: .leading).offset(x: -45, y: -320).opacity(opacidadChat)
            
            
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 530, height: 142.93878)
              .background(
                Image("Chat")
                    .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 690.77307, height: 267.93878)
                  .clipped().offset(x: -60, y: -320).opacity(opacidadChat)
              )
            
            Rectangle()
                          .foregroundColor(.clear)
                          .frame(width: 35, height: 25)
                          .background(
                            Image(systemName: "arrowshape.turn.up.forward.fill")
                              .resizable()
                              .aspectRatio(contentMode: .fill)
                              .frame(width: 35, height: 25)
                              .clipped().offset(x: 210, y: -214).foregroundColor(.black)
                            
                          ).onTapGesture {
                              
                              if (iterador<3){
                                  iterador+=1
                              }else{
                                  
                              }
                          }.opacity(opacidadChat)
            
            
        }
        .frame(width: 834, height: 1194)
        .background(Color(red: 0.95, green: 0.95, blue: 0.86))
        
        
    }
}

#Preview {
    CapituloTres()
}
